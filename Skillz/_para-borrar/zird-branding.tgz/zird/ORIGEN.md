# Origen de esta carpeta

Copia del Design System **ZIRD Motion** (claude.ai/artifact/NDJYj2WmRBxMtUqW9EgL3e), exportada el 2026-10-08.
La fuente de verdad es el Design System: si se cambia allí, hay que volver a exportarlo aquí (pídeselo a Claude: "actualiza el branding ZIRD desde el Design System").

- `README.md` → el brand book completo; la sección 9 "Para la skill de edición" es la que manda al editar.
- `tokens.json` → colores, tipografía, radios, grosores, sombras y duraciones.
- `components/<Pieza>/README.md` → cuándo y cómo se usa cada pieza; `preview.html` → referencia visual (las variables CSS de los tokens no están incluidas, así que fuera del Design System se ven sin color).
- `fonts/` → Inter e Inter Display. EB Garamond y JetBrains Mono: `@remotion/google-fonts`.
- `assets/Mario/` → avatares por plataforma y la imagen oficial del aurora.
- Logo ZIRD: pendiente (ver README §8).
