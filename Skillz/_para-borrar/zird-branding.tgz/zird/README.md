# ZIRD Motion

Sistema de diseño para los motion graphics, textos quemados e interfaces de los vídeos de YouTube y Shorts editados con la agencia **ZIRD**. Lo leen las skills de edición: cuando detectan una frase importante del guion, este documento decide **cómo se ve, de qué color es, dónde se coloca y cómo se mueve**.

> Una idea, un color, un movimiento. Apple limpio por fuera, técnico por dentro.

---

## 1. Principios

1. **Limpio antes que lleno.** Fondo blanco o gris Apple, mucho aire, un único foco por plano. Si dudas, quita.
2. **Interfaz como lenguaje.** Las ideas se cuentan con piezas de UI reales: selección de texto con handles, tooltips, ventanas macOS, pills, widgets, toggles, notificaciones. El espectador ya sabe "leerlas".
3. **El azul actúa, el amarillo celebra.** El azul ZIRD marca acción y dato; el amarillo aparece solo como chispa, marcador o pico emocional.
4. **Física suave.** Todo entra con resorte y desenfoque, nada aparece de golpe ni rebota de forma cómica.
5. **Coherencia por repetición.** Los mismos radios, grosores, sombras y curvas en todos los vídeos: así se reconoce un vídeo ZIRD sin logo.

---

## 2. Color — jerarquía y alternancia

| Rol | Token | Uso | Proporción por plano |
| --- | --- | --- | --- |
| Primario | `zird-surface` / `zird-paper` | Lienzo, tarjetas | ~70 % |
| Primario | `zird-blue` (#001AFA) | Acción, palabra clave, dato, selección, glow | ~20 % |
| Secundario | `zird-ink` (texto) · `zird-black` #0B0D12 (superficies oscuras fijas) | Texto, tooltips, pills oscuras | ~8 % |
| Secundario | `zird-yellow` (#FFF000) | Chispa, marcador, cifra que sube | **≤ 2 %** |

### Fondo aurora (firma de marca)
Definido por la imagen oficial de ZIRD: manchas grandes de `zird-blue` (#001AFA) y `zird-yellow` (#FFF000) muy difuminadas (blur 120–200px) en las esquinas/bordes, con un **centro blanco** que deja respirar al texto, más grano fino (2–3 %). Composición diagonal: azul en esquinas opuestas, amarillo en la banda intermedia. El contenido (palabra en azul bold, tarjeta, ventana) va siempre sobre el centro blanco.
- Uso: intros, cambios de capítulo, frases-statement y cierres. No detrás de UI densa.
- Movimiento: las manchas derivan muy lento (ciclo 8–12s) y "respiran" (escala ±5 %).
- Aquí, y solo aquí, azul y amarillo comparten plano a tamaño similar: el blanco central los separa.

### Reglas de alternancia azul ↔ amarillo
- **Nunca compiten en el mismo elemento** ni a igual tamaño en el mismo plano. Uno manda, el otro puntúa.
- **Ritmo A-A-B:** en una secuencia de motions, dos momentos azules por cada momento amarillo. El amarillo es el "ding" — si aparece siempre, deja de sonar.
- **Azul** = información, proceso, herramienta, "cómo". Selección de texto, flujos, gráficas, botones, ventanas activas.
- **Amarillo** = resultado, emoción, insight, "¡esto!". Sparkle ✦ junto a una palabra, marcador fluorescente, número final de un contador, estrella de logro.
- **Pareja permitida:** palabra en highlight azul + sparkle amarillo de 24–40px en la esquina superior derecha (referencia: "meaningful ✦").
- **Contraste:** texto blanco sobre azul, texto negro sobre amarillo. **Prohibido** texto amarillo sobre blanco y texto azul fino (<40px) sobre negro.
- **Modo oscuro (escenas técnicas):** fondo `zird-surface` en tema oscuro (#0B0D12), el azul pasa a `#3347FF` con `shadow-glow-blue`; el amarillo solo como punto de luz.
- Rojo/ámbar/verde (`zird-signal-red` #FF5F57, `zird-signal-amber` #FEBC2E, `zird-signal-green` #28C840) solo en semáforos de ventana y antes/después. El ámbar de macOS NO es el amarillo de marca: `zird-yellow` (#FFF000) se reserva para chispa, marcador y cifra final. Nunca rojo/verde como marca. Nada de gradientes morados.

### Nombres de tokens (sin ambigüedad)
- `zird-surface` = el fondo/lienzo, sea cual sea el tema. `zird-ink` = el texto sobre ese fondo. Usa siempre estos dos para fondo y texto.
- `zird-black` = superficie oscura FIJA (#0B0D12 en ambos temas): tooltips, pills oscuras, StatCard oscura. Texto encima siempre blanco #FFFFFF.
- `zird-aurora-blue` es un alias de `zird-blue`.

### Contraste
- Blanco sobre `zird-blue` #001AFA: 8,3:1 ✔. Negro sobre `zird-yellow`: 18:1 ✔.
- **Azul sobre negro:** #001AFA sobre #0B0D12 da **2,3:1** y #3347FF **3,2:1**. Por eso, en escenas oscuras el azul solo se usa como (a) glow/bloom, (b) fondo de botón o pill con texto blanco encima, o (c) texto de **40px o más**. Nunca texto azul < 40px sobre negro.
- Texto amarillo sobre blanco: prohibido (1,1:1).

---

## 3. Tipografía

Fuentes con archivo real en `fonts/` (lo que se renderiza en Remotion = lo que se ve en las vistas previas):

| Rol | Familia | Archivos / origen | Pesos |
| --- | --- | --- | --- |
| Titulares grandes (≥ 64px) | **Inter Display** | `fonts/InterDisplay-SemiBold.otf`, `fonts/InterDisplay-Bold.otf` | 600, 700 |
| Texto, captions, UI (< 64px) | **Inter** | `fonts/Inter-Medium.otf`, `-SemiBold.otf`, `-Bold.otf` | 500, 600, 700 |
| Editorial (frases-manifiesto) | **EB Garamond** | Google Fonts (pendiente subir archivo) — en Remotion: `@remotion/google-fonts/EBGaramond` | 400, 400 italic |
| Datos, cifras, código | **JetBrains Mono** | Google Fonts (pendiente subir archivo) — en Remotion: `@remotion/google-fonts/JetBrainsMono` | 500 |

- **Inter Display** 700 para titulares, tracking −3,5 % a −4,5 %, interlineado 0,95–1,05. **Inter** 600 para textos quemados, 500 para etiquetas.
- **EB Garamond** — voz editorial, italic 400, tracking −2 % a −6 %. Solo en Statement y contrastes ("Designers *before* AI"). Máx. 1 vez cada ~60 s. Tamaño ×1,15 respecto al sans que acompaña para igualar altura de x.
- **JetBrains Mono** 500 — cifras de contador, versiones, timestamps, código, números de capítulo.
- Mezcla canónica: titular sans + **una** palabra en Garamond italic o en highlight azul. Nunca las dos a la vez.
- Mayúsculas solo en etiquetas de 20px (`meta`). Titulares en sentence case con punto final para "statements" ("Make it speak.").
- *Nota:* el estilo de referencia es SF Pro / Apple Garamond (Apple), pero no tienen licencia de uso libre ni archivo descargable; Inter Display y EB Garamond son sus equivalentes con archivo. No usar SF Pro en render.

### Textos quemados (captions de énfasis)
- 1–4 palabras por bloque, `burned-caption` 56px (Shorts: 72–88px).
- Posición: tercio inferior centrado en YouTube (base a 160px del borde); en Shorts centro-bajo, por encima de 320px del borde.
- Palabra clave: highlight `zird-blue-tint` + barras de selección `zird-blue` con nodos circulares (componente **TextHighlight**) o color `zird-blue` sólido.
- Sin contornos ni sombras duras: legibilidad con `shadow-float` suave o una pill `zird-glass` detrás.

---

## 4. Forma, líneas y profundidad

- **Radios:** squircle Apple. Tarjetas 28px, ventanas 20px, chips 10px, botones/pills 999px.
- **Grosores (a 1080p):** hairline 1px, líneas de flujo 3px, subrayado 6px con terminación redonda, cursor de selección 4px + nodo 16px.
- **Subrayados:** trazo a mano alzada (garabato) en azul o amarillo que se "dibuja" bajo la palabra con `dur-draw`; círculo a mano alrededor de una palabra para "esto es lo importante".
- **Sombras:** largas, difusas y bajas (`shadow-float`): el objeto flota 20–30px sobre el fondo. Nunca sombras negras duras.
- **Vidrio:** paneles `zird-glass` + blur 24px + hairline blanco 1px al 40 % arriba (reflejo). Para superponer UI sobre el plano del creador.
- **Luces y destellos:** bloom azul detrás de botones en escenas oscuras; un único sparkle amarillo de 4 puntas; sweep de brillo diagonal (blanco 20 %) que cruza pills/tarjetas con `dur-draw` al aparecer.
- **Rejilla técnica:** cuadrícula 40px en `zird-hairline` al 50 % como fondo de escenas "cómo funciona"; líneas guía discontinuas para proyecciones isométricas.
- **Iconos:** estilo SF Symbols / iOS — glifo lineal 2px o app-icon squircle con relleno plano + ligero degradado vertical (5 %). Los iconos de terceros (Figma, Gmail…) se usan tal cual, sobre tile blanco con `shadow-float`.

---

## 5. Composición y posicionamiento (1920×1080)

- Margen seguro 96px. Rejilla de 12 columnas, gutter 24px.
- **Centro** → statements y titulares sueltos.
- **Tercio lateral (opuesto a la cara del creador)** → tarjetas, ventanas, widgets, datos. Nunca tapar ojos/boca.
- **Tercio inferior** → textos quemados y tooltips.
- Ángulos: UI plana frontal por defecto; isométrico 30° solo para explicar capas/procesos; inclinación 3D sutil (rotateX 8–12°) al entrar.
- Un motion = máx. 1 titular + 1 elemento de UI + 1 acento.
- Shorts (1080×1920): todo centrado, escala ×1,35, margen lateral 120px.

---

## 6. Movimiento

Tiempos medidos fotograma a fotograma sobre las 53 referencias. A 30 fps. Los tokens están en `tokens.json` → familia `duration` (valores en ms).

| Token | Duración | Remotion | CSS | Uso |
| --- | --- | --- | --- | --- |
| `dur-enter` | 270ms · 8 f | `Easing.out(Easing.quad)` | `cubic-bezier(0.5,1,0.89,1)` | Aparecer (entrada firma) |
| `dur-exit` | 180ms · 5–6 f | `Easing.in(Easing.quad)` | `cubic-bezier(0.11,0,0.5,0)` | Desaparecer: fundido + blur, nunca deslizar fuera de cuadro |
| `dur-move` | 480ms · 14–15 f | `Easing.inOut(Easing.sin)` | `cubic-bezier(0.37,0,0.63,1)` | Mover de A a B dentro del plano |
| `dur-state` | 200–280ms · 6–8 f (ref. 240) | `Easing.out(Easing.quad)` | `cubic-bezier(0.5,1,0.89,1)` | Cambio de estado: toggle, botón, color |
| `dur-stagger` | 60ms · ≈2 f | — | — | Escalonado entre palabras/ítems; la palabra clave llega la última |
| `dur-draw` | 400–600ms · 12–18 f (ref. 500) | `Easing.inOut(Easing.sin)` | `cubic-bezier(0.37,0,0.63,1)` | Líneas, subrayados, barras que se dibujan |
| `dur-gesture` | ~500ms por fase · 15 f | `Easing.inOut(Easing.sin)` | `cubic-bezier(0.37,0,0.63,1)` | Gesto (cursor va, clic, menú abre); tras cada acción, reposo ≥ igual de largo |
| `spring-pop` | ~570ms · 17 f | `spring({frame, fps, config:{damping:14, stiffness:180}})` | keyframes 0→1.15 (40 %)→0.96 (70 %)→1 | Rebote: pills, iconos, nodos, chispas que hacen pop |

- **Entrada firma ZIRD** (`dur-enter`, Easing.out(quad)): opacidad 0→1 + escala 0,94→1 + desenfoque 12px→0 + y +24px→0, todo dentro de los 8 fotogramas.
- **Salida** (`dur-exit`, Easing.in(quad)): opacidad 1→0 + desenfoque 0→12px. Sin escala ni desplazamiento.
- **Texto:** aparición por palabra (`dur-stagger`) o por línea; la palabra clave llega la última y entonces se selecciona (`dur-state`) o recibe el sparkle (`spring-pop`).
- **Líneas/flujos:** se dibujan (stroke-dashoffset) con `dur-draw`; varias líneas convergen en una (referencia "Quality questions → focused mind").
- **Números:** contador ascendente 1 s con Easing.inOut(sin); la cifra final destella en `zird-yellow` 150ms.
- **Cursor:** ver componente **Cursor** (va con `dur-move`, reposa, clic a 0,9 + onda, reposa).
- **Fondos animados:** solo AuroraBackground (deriva 8–12 s).
- **Ciclo de cada pieza:** entrada → acción(es) → reposo (mínimo 0,5 s tras cada acción; normalmente lo que dure la frase) → salida.
- Prohibido: rebotes exagerados (otro spring que no sea `spring-pop`), giros 360°, glitch, transiciones de PowerPoint, deslizar desde/hacia fuera del cuadro, más de 3 elementos animándose a la vez.

---

## 7. Biblioteca de piezas (cuándo usar cada una)

| Frase en el guion | Pieza | Color |
| --- | --- | --- |
| Concepto clave / palabra | **TextHighlight** | Azul (+ sparkle amarillo si es el insight) |
| Matiz, comentario, "dilo más alto" | **Callout** (tooltip oscuro) | `zird-black` |
| Herramienta, web, app | **WindowFrame** | Blanco + semáforos macOS reales |
| Acción / CTA | **GlassPill** | Negro → azul al activar |
| Activar / desactivar, modo A↔B | **Toggle** | Gris → azul |
| Elegir una acción dentro de una herramienta | **ContextMenu** | Vidrio + ítem azul |
| Cifra, resultado, porcentaje | **StatCard** | Azul; cifra final amarilla |
| Varias ideas que convergen | **KineticLine** | Azul → punto amarillo |
| Proceso con pasos ordenados | **StepFlow** | Azul que se rellena |
| Lista de opciones y foco en una | **ListFocus** | Ítem azul, resto atenuado |
| Llega un email, pago, venta, lead | **Notification** | Vidrio + icono de app |
| Presentar persona o marca | **LowerThird** | Vidrio + acento azul |
| Nueva sección / capítulo | **ChapterCard** | Aurora + azul |
| Tesis / frase-manifiesto | **Statement** | `zird-ink` + palabra Garamond azul |
| Intro, cierre, fondo de marca | **AuroraBackground** | Azul + amarillo + blanco |
| "Haz clic", "seleccionas" (con otra pieza) | **Cursor** | Negro + onda azul |
| "Mi Instagram", "escríbeme", "mi canal" | **SocialProfile** (avatar real de Mario por plataforma) | Blanco + azul; destello amarillo al suscribirse |

Lo que aporta la skill consumidora: el texto, el icono de terceros si aplica y el timing de la frase. El sistema aporta todo lo demás.

---

## 8. Logo ZIRD

**Estado: PENDIENTE.** El grupo de recursos `Logos` se creará con los archivos oficiales (SVG o PNG transparente): `zird-logo-positive` (azul #001AFA, para fondos blancos/claros) y `zird-logo-negative` (blanco, para fondos `zird-blue` o `zird-black`). No se dibuja ni se aproxima: hasta que estén subidos, **ninguna pieza usa logo** (se escribe "ZIRD" en Inter Display 700 solo si el guion lo exige).

Reglas (se aplican en cuanto existan los archivos):
- **Tamaño mínimo:** 120px de ancho a 1080p (160px en Shorts).
- **Área de respeto:** alrededor del logo, libre la altura de la "i" (x-height) por cada lado; nada de texto ni bordes dentro.
- **Fondos permitidos:** positivo sobre `zird-surface` blanco, `zird-paper` y el centro blanco del aurora; negativo sobre `zird-blue` y `zird-black`. **Prohibido:** sobre amarillo, sobre vídeo sin panel, con sombra, contorno, degradado, rotado o deformado.
- **Uso en vídeo:** solo en intro/cierre y ChapterCard opcional; nunca como marca de agua permanente.

---

## 9. Para la skill de edición

**Prioridad.** Este sistema manda sobre cualquier estilo genérico, plantilla o preferencia de otra skill en: color, fuentes, logo, piezas, tiempos y posiciones. Si algo no está aquí, elige la opción más sobria compatible con estas reglas.

**Formato:** YouTube 1920×1080 @30 fps; Shorts 1080×1920 @30 fps (todo centrado, escala ×1,35).

### Disparadores

| Frase del guion (patrón) | Componente | Color | Posición | En pantalla |
| --- | --- | --- | --- | --- |
| Palabra/concepto clave enfatizado | TextHighlight | Azul (+ ✦ si insight) | Tercio inferior centrado | Lo que dura la frase (1,5–3 s) |
| Aparte, matiz, gancho corto | Callout | `zird-black` | Anclado a otra pieza | 1,5–2,5 s |
| Nombra herramienta/web/app | WindowFrame | Blanco + semáforos | Tercio opuesto a la cara | 3–6 s |
| CTA, "reserva", "dale a…" | GlassPill (+ Cursor) | Negro → azul | Tercio inferior / centro en CTA final | 2–3 s |
| "Activas…", "modo…", binario | Toggle (+ Cursor) | Gris → azul | Tercio inferior | 2–3 s |
| "Le das a…", acción en menú | ContextMenu (+ Cursor) | Vidrio + azul | Sobre WindowFrame u objetivo | 2,5–4 s |
| Cifra, %, resultado | StatCard | Azul; cifra final ✦ amarilla | Tercio opuesto a la cara | 2,5–4 s |
| "Todo esto lleva a…", convergencia | KineticLine | Azul → punto amarillo | Centro / tercio lateral | 2,5–3,5 s |
| "Primero… después…", pasos | StepFlow | Azul | Tercio inferior / centro | 1 s + 1 s por paso |
| Enumera y se centra en uno | ListFocus | Ítem azul | Tercio opuesto a la cara | 3–5 s |
| "Te llega…", pago, email, lead | Notification | Vidrio | Arriba centrado (iOS) / arriba-derecha (macOS) | 2–3 s |
| Presenta persona/marca | LowerThird | Vidrio + acento azul | Abajo-izquierda en margen seguro | 3–5 s |
| Nueva sección/capítulo | ChapterCard | Aurora + azul | Pantalla completa | 2–3 s |
| Tesis citable (≤ 8 palabras) | Statement | `zird-ink` + palabra Garamond azul | Centro | 2–4 s |
| Intro / cierre | AuroraBackground (+ Statement o logo) | Aurora | Pantalla completa | 2–5 s |
| "Mi Instagram", "escríbeme", "mi canal" | SocialProfile | Blanco + azul (+ ✦ al suscribirse) | Tercio opuesto / centro en cierre | 3–4 s |

Si una frase encaja en varios: prioridad Statement > ChapterCard > StatCard > StepFlow/ListFocus > WindowFrame > TextHighlight.

### Límites duros
- Máximo **3 elementos animándose a la vez**.
- Máximo **1 chispa amarilla** (✦, cifra final o punto) por plano.
- Ritmo **A-A-B**: dos motions azules por cada motion con amarillo.
- **Statement** como máximo una vez cada ~60 s; **SocialProfile** 1–2 veces por vídeo.
- Un motion = máx. 1 titular + 1 pieza de UI + 1 acento.
- Nunca tapar ojos ni boca del creador; respetar margen seguro 96px (Shorts: 120px laterales, 320px abajo).
- Solo tiempos y curvas de §6; solo fuentes de §3; solo colores de `tokens.json`.

### Checklist antes de dar un motion por bueno
1. ¿La pieza es la de la tabla de disparadores para esa frase?
2. ¿Entra con `dur-enter` (8 f, Easing.out(quad)) y sale con `dur-exit` (5–6 f, Easing.in(quad)), sin deslizar fuera de cuadro?
3. ¿Hay un reposo ≥ 0,5 s tras cada acción y el motion dura lo que la frase?
4. ¿Colores solo de tokens, con fondo `zird-surface` y texto `zird-ink`? ¿Contraste ok (nada de azul < 40px sobre negro, nada de amarillo sobre blanco)?
5. ¿Una sola chispa amarilla como máximo y ritmo A-A-B respetado?
6. ¿Fuentes Inter Display / Inter / EB Garamond / JetBrains Mono, con el estilo de texto correcto?
7. ¿Radios, grosores y sombras de los tokens (28 / 20 / 10 / pill; 1 / 3 / 6 / 4px; `shadow-float`)?
8. ¿Dentro del margen seguro y sin tapar la cara?
9. ¿≤ 3 elementos animándose a la vez?
10. ¿Semáforos de ventana en rojo/ámbar/verde de macOS, no en amarillo de marca?
