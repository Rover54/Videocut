# Mario — avatares y marca

- `avatar-instagram.jpg` — retrato de estudio (polo azul marino, fondo gris). Úsalo siempre que se hable de **Instagram** (@marioheern_) o de DMs.
- `avatar-youtube.jpg` — foto casual (gorra, gafas). Úsalo siempre que se hable del **canal de YouTube** (@MarioHernAs).
- `zird-aurora.jpg` — imagen de marca ZIRD: referencia oficial de azul #001AFA, amarillo #FFF000 y del fondo aurora.

Nunca mezclar: cada avatar va con su plataforma. Siempre en círculo, con aro según plataforma (ver componente SocialProfile).
