Pasos conectados por una línea que se va rellenando en azul.

**Cuándo:** el guion explica un proceso con orden ("primero…, después…, por último…", "paso 1, 2, 3", "el sistema tiene 4 fases"). Si son ideas que confluyen sin orden, usa **KineticLine**.

**Colores:** nodos circulares 44px; pendiente: `zird-surface` + borde `zird-hairline` + número `zird-ink-muted`; completado: `zird-blue` + número blanco. Línea base `zird-hairline` 3px; relleno `zird-blue` 3px. Etiquetas `label` en `zird-ink` bajo cada nodo.

**Posición:** horizontal en el tercio inferior o centrado (YouTube); vertical centrado en Shorts. 3–5 pasos.

**Animación (tokens §6):** nodos entran con `dur-enter` y `dur-stagger` → el relleno avanza tramo a tramo con `dur-move` (Easing.inOut(sin)), sincronizado con cada "paso" de la voz → el nodo alcanzado cambia con `dur-state` → reposo ≥ 0,5 s entre tramos → salida `dur-exit`.

**La skill aporta:** nombres de los pasos y el instante en que se nombra cada uno.
