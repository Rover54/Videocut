Widget de dato para cifras, resultados y porcentajes.

**Cuándo:** el guion dice una cifra, un resultado o un porcentaje ("pasamos de 10k a 50k", "+48 % de retención", "6M facturados").

**Colores:** tarjeta `zird-black` (escena oscura) o `zird-surface` (clara), radio `radius-card`, padding `space-3`. Etiqueta `meta` en `zird-ink-muted` (#A3A9B8 sobre negro). Cifra en `numeric`/`headline`. Barra de progreso `zird-blue` 6px con glow; la cifra final destella `zird-yellow` 150ms (es la chispa amarilla del plano).

**Posición:** tercio lateral opuesto a la cara.

**Animación (tokens §6):** entrada firma → contador y barra suben juntos 1 s con Easing.inOut(sin) → al llegar, destello amarillo 150ms y vuelta → reposo → salida `dur-exit`.

**La skill aporta:** cifra inicial/final, unidad, etiqueta.
