Líneas que se dibujan para explicar convergencia de ideas o causa → efecto.

**Cuándo:** "todo esto lleva a…", "varias cosas que se juntan en una", "de X a Y" (referencia "Quality questions → focused mind"). Para pasos numerados usa **StepFlow**.

**Colores:** trazo `zird-blue` 3px (`stroke-line`), terminación redonda; punto final `zird-yellow` con `shadow-glow-yellow` (chispa del plano). Etiquetas `label` en `zird-ink` a ambos lados.

**Posición:** centro del plano o tercio lateral; ancho ≥ 40 % del cuadro.

**Animación (tokens §6):** líneas de origen se dibujan con `dur-draw` y `dur-stagger` → la línea común después → punto final con `spring-pop` → reposo → salida `dur-exit`.

**La skill aporta:** etiqueta de origen (o varias) y de destino.
