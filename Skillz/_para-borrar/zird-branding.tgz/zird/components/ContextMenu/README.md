Menú contextual estilo macOS que se despliega desde un clic del cursor, con un ítem resaltado en azul.

**Cuándo:** el guion describe una elección o acción dentro de una herramienta ("le das a duplicar", "eliges exportar", "tienes tres opciones aquí") o enumera acciones posibles.

**Colores:** panel `zird-glass` + blur 24px + borde `zird-hairline`, radio 14px, `shadow-float`; ítems 15px `zird-ink` con atajo en `zird-ink-muted`; separadores `zird-hairline`; resaltado `zird-blue` con texto blanco, radio 8px.

**Posición:** se abre desde el punto del clic, hacia abajo-derecha; dentro de un WindowFrame o sobre un elemento objetivo.

**Animación (tokens §6):** Cursor llega con `dur-move` → reposo → clic (0,9 + onda) → el menú se abre desde el punto del clic con `dur-enter` (escala 0,94→1, origen arriba-izquierda) → reposo → el resaltado baja al ítem elegido con `dur-move` → reposo ≥ 0,5 s → salida `dur-exit`.

**La skill aporta:** 3–6 ítems, cuál se elige y el objeto sobre el que se hace clic.
