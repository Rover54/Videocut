Botón/pill para CTAs, opciones y estados.

**Cuándo:** el guion propone una acción o elección ("reserva una llamada", "dale a seguir", "elige A o B").

**Colores:** inactivo `zird-black` (o `zird-glass` sobre vídeo) con texto blanco; activo `zird-blue` + texto blanco + `shadow-glow-blue` en escenas oscuras. Radio `radius-pill`, alto 64–88px, icono circular blanco a la derecha con flecha.

**Posición:** tercio inferior o junto al elemento que activa; en CTAs finales, centrado.

**Animación (tokens §6):** entrada firma → el Cursor llega con `dur-move` (Easing.inOut(sin)) → reposo → clic (cursor 0,9 + onda) → cambio de estado negro→azul con `dur-state` y la flecha gira 45° → reposo ≥ 0,5 s → salida `dur-exit`.

**La skill aporta:** texto del botón (≤ 4 palabras) y si se pulsa.
