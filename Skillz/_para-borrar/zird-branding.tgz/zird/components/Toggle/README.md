Interruptor de iOS que cambia de estado al clic del cursor.

**Cuándo:** el guion habla de activar/desactivar, un antes/después binario o un cambio de modo ("activas esto y…", "modo piloto automático", "de manual a automático").

**Colores:** pista 88×52 (a 1080p: 132×78) radio `radius-pill`; apagado `#D7DAE0`, encendido `zird-blue` (no el verde de iOS: es la marca). Mando blanco con `shadow-float`. Etiqueta `label` `zird-ink` a la izquierda; opcional par "Manual | Automático" con el lado activo en `zird-ink` y el otro en `zird-ink-muted`.

**Posición:** tercio inferior o junto al concepto; nunca solo en medio sin etiqueta.

**Animación (tokens §6):** entrada firma → Cursor llega con `dur-move` → reposo → clic (0,9 + onda) → mando se desplaza y pista cambia de color con `dur-state` (Easing.out(quad)) → reposo ≥ 0,5 s → salida `dur-exit`.

**La skill aporta:** etiqueta(s) y estado final.
