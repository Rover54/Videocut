Notificación genérica de iOS/macOS (app, título, texto). Para DMs de Mario usa la variante DM de **SocialProfile**.

**Cuándo:** el guion habla de algo que "llega" o "avisa": un pago, un email, una venta, un lead, un mensaje de un cliente ("te llega un email", "ding, otra venta").

**Colores:** banner `zird-glass` + blur 24px, radio 22px, `shadow-float`. Icono de app 40px squircle (radio 9px; icono real de terceros cuando exista). App y hora 13px `zird-ink-muted` en mayúsculas no; título 15px 600 `zird-ink`; texto 15px 400 `zird-ink`. Cifra de venta: puede llevar la chispa `zird-yellow` si es el pico del plano.

**Posición:** parte superior centrada (como iOS), 96px del borde superior; en macOS arriba-derecha. Se pueden apilar 2–3 (cada una 8px más abajo y escala 0,96).

**Animación (tokens §6):** entrada firma `dur-enter` (no deslizar desde fuera del cuadro) → icono `spring-pop` → reposo 1,5–2,5 s → salida `dur-exit`. Apiladas: `dur-stagger` ×4.

**La skill aporta:** app, icono, título, texto (≤ 12 palabras).
