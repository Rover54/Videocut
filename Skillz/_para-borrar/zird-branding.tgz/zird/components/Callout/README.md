Tooltip oscuro con flecha que comenta o amplifica una frase ("Dilo más alto").

**Cuándo:** el creador hace un matiz, un aparte o una frase-gancho corta que comenta lo que hay en pantalla ("ojo con esto", "dilo más alto", "pensar vs generar"). Variante menú segmentado para dos opciones ("Think | Generate").

**Colores:** fondo `zird-black` (superficie oscura fija), texto blanco estilo `label`, radio 14px, flecha 12px centrada, `shadow-float`. Separador del menú: hairline blanco 20 %.

**Posición:** anclado bajo o sobre un TextHighlight o un elemento de UI, nunca suelto en medio del plano.

**Animación (tokens §6):** aparece con `spring-pop` desde escala 0 (origen en la flecha) + fundido → reposo mientras dure la frase → salida `dur-exit`.

**La skill aporta:** texto (≤ 6 palabras) o 2 opciones, y el elemento al que se ancla.
