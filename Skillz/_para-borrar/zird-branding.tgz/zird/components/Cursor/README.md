Puntero de macOS para guiar la mirada y disparar acciones (clics en GlassPill, Toggle, ContextMenu, WindowFrame).

**Cuándo:** siempre que una pieza cambia de estado "porque alguien la usa", o el guion dice "le das aquí", "haces clic", "seleccionas".

**Forma y color:** flecha macOS 22×30px a 1080p (33×45 en Shorts), relleno `#0B0D12`, contorno blanco 1,6px, sombra `0 2px 4px rgba(0,0,0,.25)`. Onda de clic: anillo `zird-blue` 2px, 36px → ×1,6 desvaneciéndose.

**Reglas:**
- Entra con fundido `dur-enter` ya dentro del cuadro (nunca desde fuera).
- Se desplaza en línea recta o curva suave con `dur-move` (Easing.inOut(Easing.sin)); nunca velocidad constante.
- Reposa ≥ 0,5 s antes de cada clic (`dur-gesture`).
- Clic: se hunde a escala 0,9 en 80ms y vuelve en 120ms (Easing.out(quad)); la onda sale a la vez durante 0,4 s.
- Tras la acción, reposo ≥ 0,5 s; luego sale con `dur-exit` o sigue a la siguiente acción.
- Un solo cursor en pantalla. Punta del cursor = punto exacto del clic.

**La skill aporta:** punto de inicio y objetivo(s) de clic.
