Rótulo con nombre y cargo de una persona o una marca, en el tercio inferior.

**Cuándo:** aparece por primera vez una persona (invitado, cliente, el propio Mario en la intro) o se menciona una marca/empresa concreta ("trabajé con X, fundador de Y").

**Colores:** tarjeta `zird-glass` (sobre vídeo) o `zird-surface` (sobre fondo limpio), radio 18px, `shadow-float`, borde hairline blanco 40 % arriba. Barra de acento vertical `zird-blue` 4px. Nombre 28px Inter 700 `zird-ink`; cargo 18px Inter 500 `zird-ink-muted`. Avatar o logo opcional 48px circular.

**Posición:** abajo-izquierda dentro del margen seguro (96px laterales, base a 120px del borde), del lado de la persona nombrada. Shorts: centrado sobre el tercio inferior.

**Animación (tokens §6):** tarjeta con `dur-enter` → barra de acento se dibuja con `dur-draw` → nombre y cargo con `dur-enter` y `dur-stagger` → reposo 2–4 s → salida `dur-exit`.

**La skill aporta:** nombre, cargo/descripción, avatar o logo opcional.
