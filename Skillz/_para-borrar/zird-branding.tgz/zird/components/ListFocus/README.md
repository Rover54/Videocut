Lista apilada en la que el ítem que se nombra sube al centro y gana foco; el resto queda atenuado.

**Cuándo:** el guion enumera opciones/pilares y luego se centra en uno ("hay cinco pilares… hoy hablamos de **ventas**"), o recorre una lista ítem a ítem (repetir el foco por ítem).

**Colores:** ítems en pills `zird-surface` con borde `zird-hairline`, texto `label` `zird-ink`, radio `radius-card` (alto 52–64px). Ítem enfocado: `zird-blue` + texto blanco + `shadow-float`, escala 1,08. Resto: opacidad 35 % + blur 1,5px. Icono opcional estilo SF Symbols a la izquierda.

**Posición:** tercio lateral opuesto a la cara; 3–7 ítems.

**Animación (tokens §6):** ítems entran con `dur-enter` y `dur-stagger` → reposo → la lista se desplaza para centrar el ítem con `dur-move` (Easing.inOut(sin)) → foco con `dur-state` → reposo ≥ 0,5 s → (siguiente ítem: repetir) → salida `dur-exit`.

**La skill aporta:** lista de ítems (≤ 7, ≤ 3 palabras cada uno), índice enfocado y su timing.
