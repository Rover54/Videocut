Ventana macOS / navegador para mostrar herramientas, webs, apps o capturas.

**Cuándo:** el guion nombra una herramienta, web, app o proceso en pantalla ("entro en Notion", "esta web", "en el panel de Stripe").

**Colores:** fondo `zird-surface`, barra superior 40px `zird-paper` con semáforos 12px en los colores REALES de macOS: `zird-signal-red` #FF5F57, `zird-signal-amber` #FEBC2E, `zird-signal-green` #28C840 (nunca el amarillo de marca). Borde `zird-hairline`, radio `radius-window`, `shadow-float`. URL en pill `zird-surface` con texto `zird-ink-muted`.

**Posición:** tercio opuesto a la cara del creador, ancho 50–60 % del cuadro.

**Animación (tokens §6):** entrada firma (`dur-enter`, Easing.out(quad)) con inclinación opcional rotateX 10°→0 → contenido interior se dibuja con `dur-draw` y `dur-stagger` → reposo → salida `dur-exit`.

**La skill aporta:** captura o contenido, URL o título de la app.
