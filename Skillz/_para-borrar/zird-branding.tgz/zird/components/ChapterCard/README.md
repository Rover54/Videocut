Cortinilla de cambio de capítulo sobre el fondo aurora, con número y título.

**Cuándo:** el guion abre una sección nueva ("vamos con el segundo punto", "parte 3: …") o coincide con un capítulo de YouTube.

**Colores:** fondo **AuroraBackground**. Número en `numeric` (JetBrains Mono 500) `zird-blue` dentro de pill `zird-surface` (radio `radius-pill`, "02"); título `headline` Inter Display 700 en `zird-blue` (#001AFA sobre blanco central: 8,3:1), máximo 5 palabras. Sin chispa amarilla (el aurora ya lleva el amarillo).

**Posición:** pantalla completa; número y título centrados en el centro blanco del aurora.

**Animación (tokens §6):** aurora con fundido `dur-enter` → número y título con entrada firma y `dur-stagger` ×2 → reposo 1,5–2,5 s con la deriva del aurora → salida `dur-exit` de todo. Duración total 2–3 s.

**La skill aporta:** número de capítulo y título.
