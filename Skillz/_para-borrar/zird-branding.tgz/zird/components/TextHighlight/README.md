Selección de texto estilo iOS que marca la palabra clave de una frase quemada.

**Cuándo:** la frase contiene un concepto clave, una definición o una palabra que el creador enfatiza con la voz ("lo importante es **X**", "esto se llama **X**").

**Colores:** relleno `zird-blue-tint`, barras `zird-blue` de 4px (`stroke-cursor`) con nodo circular 16px arriba-izquierda y abajo-derecha, radio `radius-chip`. Texto `zird-ink`. Variante insight: sparkle `zird-yellow` (✦ 4 puntas, 24–40px) en la esquina superior derecha — cuenta como la chispa amarilla del plano.

**Posición:** tercio inferior centrado (YouTube, base a 160px del borde) o centro del plano si va sola. Estilo `burned-caption` (Shorts 72–88px).

**Animación (tokens §6):** palabras con `dur-enter` y `dur-stagger` 60ms, la clave la última → el highlight barre con `dur-state` (Easing.out(quad)) → nodos con `spring-pop` → (insight) sparkle con `spring-pop` 0,5 s después → reposo → salida `dur-exit`.

**La skill aporta:** frase (1–4 palabras), palabra clave, si es insight (sparkle sí/no).
