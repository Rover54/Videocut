Tarjetas de perfil personalizadas de Mario para cuando el guion menciona su Instagram, su canal de YouTube o "escríbeme por Instagram".

**Cuándo** (disparadores en el guion): "mi Instagram", "sígueme", "escríbeme / mándame un DM", "mi canal", "suscríbete", "en YouTube". Uso puntual: máx. 1–2 veces por vídeo, normalmente en CTA y cierre.

**Variantes**
- **Instagram** — avatar `assets/Mario/avatar-instagram.jpg` con aro degradado de stories, `marioheern_` + check verificado azul, "Mario Hernández", stats (127 publicaciones · 2.339 seguidores) y pill `zird-blue` "Seguir".
- **YouTube** — avatar `assets/Mario/avatar-youtube.jpg`, "Mario Hernandez / Infoproductos", `@MarioHernAs`, pill negra "Suscribirse" que al clic del cursor pasa a "Suscrito ✓" con destello `zird-yellow`.
- **DM** — notificación iOS estilo Messages/Instagram: avatar pequeño, "marioheern_", "Escríbeme «QUIERO» y te cuento cómo…" (la skill pone la palabra clave real en highlight `zird-blue-tint`).

**Estilo**: tarjeta `zird-glass` o `zird-surface`, radio `radius-card`, `shadow-float`; avatar circular 96px (Shorts 128px). Entrada firma (`dur-enter`) con `dur-stagger`; el avatar hace `spring-pop`; en YouTube el botón cambia "Suscribirse"→"Suscrito ✓" con `dur-state` y una chispa `zird-yellow` (`spring-pop`); reposo; salida `dur-exit`. Posición: tercio opuesto a la cara, o centrado sobre fondo aurora en el cierre.

**La skill aporta**: plataforma, CTA/palabra clave del DM y, si cambian, cifras actualizadas (las de aquí son de octubre 2026).
