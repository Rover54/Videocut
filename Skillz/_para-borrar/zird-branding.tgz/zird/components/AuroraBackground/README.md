El fondo aurora de marca (imagen oficial ZIRD) como componente.

**Cuándo:** intros, ChapterCard, Statement de apertura/cierre, CTA final y pantallas de cierre. Nunca detrás de UI densa ni durante más de 5 s seguidos.

**Parámetros (a 1920×1080):**
- Lienzo base: `#FFFFFF` (centro blanco libre ≥ 45 % del ancho y 40 % del alto).
- Manchas `zird-aurora-blue` (#001AFA): 2, en esquinas opuestas (arriba-izquierda y abajo-derecha), elipses de ~60 % × 70 % del cuadro, centro fuera del cuadro (−15/−25 %).
- Manchas `zird-yellow` (#FFF000): 2, bandas inclinadas −12° entre las azules (abajo-izquierda y arriba-derecha), ~65 % × 45 %.
- Desenfoque: 160–200px a 1080p (en la vista previa 70px por la escala).
- Grano: ruido fractal monocromo, opacidad 6–10 %, mezcla multiply, estático (o a 12 fps).
- Deriva: cada mancha se traslada ±3–5 % y escala ±5 % en un ciclo de 8–12 s (duraciones distintas por mancha: 9, 10, 11, 12 s) con Easing.inOut(Easing.sin), ida y vuelta.
- Contenido encima: siempre sobre el centro blanco; texto en `zird-blue` o `zird-ink`.

**Animación (tokens §6):** fundido de entrada `dur-enter` y de salida `dur-exit`; entre medias solo la deriva lenta.

**La skill aporta:** nada (opcional: espejo horizontal para variar).
