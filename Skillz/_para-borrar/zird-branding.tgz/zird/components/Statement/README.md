Frase-manifiesto centrada, con UNA palabra en EB Garamond italic.

**Cuándo:** la frase es una tesis o lema del vídeo, citable, de ≤ 8 palabras ("Construye el sistema, no el *caos*"). Máximo 1 vez cada ~60 s. No combinar con TextHighlight en el mismo plano.

**Colores:** fondo `zird-surface` liso o **AuroraBackground** (en intros/cierres). Texto `zird-ink` en `title`/`headline` Inter Display 700, tracking −3,5 %; la palabra clave en `serif-accent` (EB Garamond italic 400, misma altura de x aproximada: ×1,15 del tamaño sans) y en `zird-blue`. Sin chispa amarilla salvo que sea el cierre del vídeo.

**Posición:** centro absoluto, máximo 2 líneas, ancho ≤ 70 % del cuadro.

**Animación (tokens §6):** palabras con `dur-enter` y `dur-stagger`; la palabra Garamond llega la última con +0,1 s de pausa → reposo 1,5–3 s → salida `dur-exit` de todo a la vez.

**La skill aporta:** la frase y la palabra en Garamond.
