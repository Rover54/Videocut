# Del tipo de frase al tipo de visual

Para cada frase elegida, hazte la pregunta del editor: **¿qué tiene que ver el espectador para entenderlo aunque no estuviera escuchando?** La respuesta es el visual.

## Correspondencia

| Tipo de frase | Qué hace el visual | Ejemplos de animación | Posición habitual |
|---|---|---|---|
| Concepto nuevo | **Presentarlo**: darle un nombre y una forma que se pueda reconocer después | Nombre grande con una definición de pocas palabras; icono o símbolo que lo represente desde entonces | Pantalla completa la primera vez |
| Explicación / mecanismo | **Representarlo**: hacer visible cómo funciona | Diagrama, flujo de nodos, causa → efecto, interfaz dibujada | Pantalla completa |
| Dato o prueba | **Mostrarlo** con magnitud | Cifra que sube, gráfico, comparación de barras, captura del resultado real | Superpuesto si la cara aporta; completa si el dato es el protagonista |
| Pasos o lista | **Ordenarlo** | Lista que entra en cascada, pasos conectados, contador de paso ("2 de 5") | Pantalla completa o lateral |
| Comparación | **Enfrentarlo** | Antes/después, dos columnas, tachado del mito | Pantalla completa |
| Metáfora | **Hacerla literal** | La imagen de la comparación ("un cubo con agujeros") | Pantalla completa o superpuesto |
| Promesa o gancho | **Fijarla** | Texto grande con las mismas palabras del título | Superpuesto |
| Remate | **Subrayarlo** | Subtítulo de énfasis, palabra realzada | Superpuesto |
| Nombre de persona, marca o herramienta | **Identificarlo** | Rótulo, logo real | Superpuesto |
| Cambio de tema | **Situar** al espectador | Cortinilla de capítulo con el progreso ("2 de 6") | Pantalla completa |

## Superpuesto o pantalla completa
- Cuando **la persona** es el contenido (opinión, emoción, historia, cierre), el visual acompaña y la cara manda: superpuesto.
- Cuando **la idea** es el contenido (concepto, proceso, cifra), el visual sustituye a la cara: pantalla completa.

## Reglas de cada animación
- **Una idea por animación.** Si una frase tiene dos ideas, son dos animaciones o se elige una.
- **El texto sale de la frase.** De 2 a 7 palabras, con las palabras que se dicen, para que el espectador lea lo que oye. Escríbelo literal en el plan.
- **Entra con la palabra clave**, no antes: si aparece antes de decirse, revienta el momento.
- **Usa las plantillas del creador** de `motion/` y su branding del perfil. Si ninguna plantilla encaja, propón una nueva y márcala como **plantilla nueva** en el plan: amplía el branding y debe aprobarla el creador.
- **Sistemas visuales:** lo que se repite en el vídeo se representa siempre igual. Si la idea clave 2 tiene un icono, ese icono vuelve cada vez que se habla de ella. Los pasos 1, 2 y 3 usan la misma plantilla. La repetición crea lenguaje y hace que el vídeo parezca una sola pieza.
- **Recursos del creador primero:** si en `recursos/` hay una captura o un b-roll real que muestra lo que se dice, suele ser mejor que una animación.
